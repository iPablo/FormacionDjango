package com.emergya.utils;

/**
 * Generic class to do pre-steps and post-steps method
 * @author Jose Antonio Sanchez <jasanchez@emergya.com>
 */
public class Factory extends DefaultTestSet {
    // Generic class to do pre-steps and post-steps method
}
